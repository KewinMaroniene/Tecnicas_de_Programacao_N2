typedef struct {
  char nome[50];
  int idade;
  char genero;
  char profissao[30];
} Comprador;

typedef struct {
  char tipo[20];
  int qtd_rodas;
  int ano;
  char modelo[20];
  float preco;
} Produto;

typedef struct {
  char seguro;
  char multimidia;
  char alarme;
  float total_add;
} Adicionais;

typedef struct {
  Comprador c;
  Produto p;
  Adicionais a;
  char data[11];
  char hora[6];
  float valor_total;
} Venda;