float CalculoTotal(Produto p, Adicionais a, Venda v){
  float preco_Produto = p.preco;
  float total_Add = 0;
  float valor_Total = v.valor_total;
  //Seguro
  switch(a.seguro){
    case 's':
    case 'S':
        total_Add += 215.50;
      break;
    case 'n':
    case 'N':
      break;
  }
  //Multimídia
  switch(a.multimidia){
    case 's':
    case 'S':
        total_Add += 2137.45;
      break;
    case 'n':
    case 'N':
      break;
  }
  //Alarme
  switch(a.alarme){
    case 's':
    case 'S':
        total_Add += 731.16;
      break;
    case 'n':
    case 'N':
      break;
  }
  
  valor_Total = preco_Produto + total_Add;
  
  
  return valor_Total;
}