void Menu(Comprador c, Produto p, Adicionais a, Venda v) {
  int opc;

LoopMenu:
  system("clear");
  printf("1 | Cadastrar comprador\n");
  printf("2 | Informar produto escolhido\n");
  printf("3 | Informar produtos adicionais\n");
  printf("4 | Cadastrar dados da venda\n");
  printf("5 | Confirmar compra\n");
  printf("6 | Consultar compra\n");
  printf("7 | Sair\n");
  printf("Digite a opção: ");
  scanf("%d", &opc);
  clear();
  endl();

  switch (opc) {
  case 1:
    CadastroComprador(c);
    goto LoopMenu;
    break;

  case 2:
    CadastroProduto(p);
    clear();
    goto LoopMenu;
    break;

  case 3:
    CadastroAdicionais(a);
    clear();
    goto LoopMenu;
    break;

  case 4:
    CadastroVenda(c, p, a, v);
    clear();
    goto LoopMenu;
    break;

  case 5:
    ConfirmacaoVenda(c, p, a, v);
    clear();
    goto LoopMenu;
    break;

  case 6:
    Consulta();
    clear();
    goto LoopMenu;
    break;

  case 7:
    _Exit(0);
    break;
  }
}