void GravacaoComprador(Comprador c) {
  FILE *arq;

  arq = fopen("Dados/clientes.txt", "w");

  //fprintf(arq, "\n%s;%d;%c;%s", c.nome, c.idade, c.genero, c.profissao);

  fprintf(arq, "%s;", c.nome);

  fclose(arq);
}

void GravacaoProduto(Produto p) {
  FILE *arq;

  arq = fopen("Dados/produtos.txt", "w");

  //fprintf(arq, "\n%s;%d;%d;%s;%.2f", p.tipo, p.qtd_rodas, p.ano, p.modelo, p.preco);

  fprintf(arq, "%s;%.2f;", p.tipo, p.preco);

  fclose(arq);
}

void GravacaoAdicionais(Adicionais a) {
  FILE *arq;

  arq = fopen("Dados/adicionais.txt", "w");

  //fprintf(arq, "\n%c;%c;%c;%.2f", a.seguro, a.multimidia, a.alarme, a.total_add);
  fprintf(arq, "%.2f;", a.total_add);

  fclose(arq);
}

void GravacaoVenda(Venda v){
  FILE *arq;

  arq = fopen("Dados/venda.txt", "w");

  fprintf(arq, "%s;%s", v.data, v.hora);

  fclose(arq);
}

void GravacaoDados(char data[50], char hora[50], char nome[50], char tipo[50], float valor_total){
  //Declaração das variávei
    FILE *arq;
    char nome_Arq[50] = "Dados/";

  //Concatenações
    strcat(nome_Arq, data);
    strcat(nome_Arq, "_");
    strcat(nome_Arq, hora);

  //Ex. final: 12-12-1212_12.12.txt
    strcat(nome_Arq, ".txt");

  arq = fopen(nome_Arq, "w");
  
  fprintf(arq, "%s;%s;%.2f", nome, tipo, valor_total);
  //fprintf(arq, "\n\nsalvou");

  fclose(arq);
}