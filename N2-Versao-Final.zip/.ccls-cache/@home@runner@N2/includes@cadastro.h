void CadastroComprador(Comprador c){
  // Leitura dos dados
  printf("Nome: ");
  fgets(c.nome, sizeof(c.nome), stdin);
  retiraQuebra(c.nome);

  printf("Idade: ");
  scanf("%d", &c.idade);
  clear();

  printf("Gênero (M/F): ");
  scanf("%c", &c.genero);
  clear();

  printf("Profissão: ");
  fgets(c.profissao, sizeof(c.profissao), stdin);
  retiraQuebra(c.profissao);

  GravacaoComprador(c);
}

void CadastroProduto(Produto p) {
  // Leitura dos dados
  printf("Tipo: ");
  fgets(p.tipo, sizeof(p.tipo), stdin);
  retiraQuebra(p.tipo);

  printf("Quantidade de Rodas: ");
  scanf("%d", &p.qtd_rodas);
  clear();

  printf("Ano: ");
  scanf("%d", &p.ano);
  clear();

  printf("Modelo: ");
  fgets(p.modelo, sizeof(p.modelo), stdin);
  retiraQuebra(p.modelo);

  printf("Preço: ");
  scanf("%f", &p.preco);

  GravacaoProduto(p);
}

void CadastroAdicionais(Adicionais a){
  float total_Add = 0;
//Leitura dos dados
  printf("S ou N\n");
  printf("Seguro: ");
  scanf("%c", &a.seguro);
  clear();

  printf("Multimídia: ");
  scanf("%c", &a.multimidia);
  clear();

  printf("Alarme: ");
  scanf("%c", &a.alarme);

    //Seguro
    switch(a.seguro){
      case 's':
      case 'S':
          total_Add += 215.50;
        break;
      case 'n':
      case 'N':
        break;
    }
    //Multimídia
    switch(a.multimidia){
      case 's':
      case 'S':
          total_Add += 2137.45;
        break;
      case 'n':
      case 'N':
        break;
    }
    //Alarme
    switch(a.alarme){
      case 's':
      case 'S':
          total_Add += 731.16;
        break;
      case 'n':
      case 'N':
        break;
    }
    a.total_add = total_Add;

    GravacaoAdicionais(a);
}

void CadastroVenda(Comprador c, Produto p, Adicionais a, Venda v){
  //Funcao de calculo de valores
    v.valor_total = CalculoTotal(p, a, v);
  
  // Leitura dos dados
    printf("Data da Venda (dd-mm-aaaa): ");
    fgets(v.data, sizeof(v.data), stdin);
    retiraQuebra(v.data);
    clear();
  
    printf("Hora da Venda (hh.mm): ");
    fgets(v.hora, sizeof(v.hora), stdin);
    retiraQuebra(v.hora);

  GravacaoVenda(v);
}