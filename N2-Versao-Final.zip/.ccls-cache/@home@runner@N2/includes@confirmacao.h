void ConfirmacaoVenda(Comprador c, Produto p, Adicionais a, Venda v){
  //Declaração dos arquivos
    FILE *arq_Comp = fopen("Dados/clientes.txt", "r");
    FILE *arq_Prod = fopen("Dados/produtos.txt", "r");
    FILE *arq_Adic = fopen("Dados/adicionais.txt", "r");
    FILE *arq_Vend = fopen("Dados/venda.txt", "r");

  //Declaração das variáveis
    char nome[50], tipo[50], data[50], hora[50], opc;
    float preco_Prod, preco_Adic;

  //Leitura e armazenamento dos dados dos arquivos
    fscanf(arq_Comp, "%50[^;]", &nome);
    fscanf(arq_Prod, "%50[^;];%f", &tipo, &preco_Prod);
    fscanf(arq_Adic, "%f", &preco_Adic);
    fscanf(arq_Vend, "%50[^;];%50[^;]", &data, &hora);

  //Calculo do preço final da compra
    float preco_Final = preco_Prod + preco_Adic;

  //Informações finais da compra
  printf("As informações da compra são:");
  printf("\nNome do comprador: %s", nome);
  printf("\nTipo do produto: %s", tipo);
  printf("\nPreco do produto: %.2f", preco_Prod);
  printf("\nPreco dos adicionais: %.2f", preco_Adic);
  printf("\nPreco final: %.2f", preco_Final);


  //Loop de confirmação da compra
  LoopCompra:
  printf("\n\nVocê deseja confirmar a compra (S/N)?: ");
  scanf("%c", &opc);

  switch(opc){
    case 's':
    case 'S':
        //Caso o usuário confirme a compra, os dados serão gravados em um arquivo único
        GravacaoDados(data, hora, nome, tipo, preco_Final);
      break;

    case 'n':
    case 'N':
      break;

    //Loop de erro de digitação
    default:
        printf("Opção inválida!\n\n");
        clear();
        clear();
        system("clear");
        goto LoopCompra;
      break;
  }
}