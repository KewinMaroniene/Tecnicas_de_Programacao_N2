#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "includes/structs.h"
#include "includes/utils.h"
#include "includes/gravacao.h"
#include "includes/calculo.h"
#include "includes/cadastro.h"
#include "includes/confirmacao.h"
#include "includes/consulta.h"
#include "includes/menu.h"

/*
a)   Kewin Denian da Silva Maroniene

b)   Sistema de Registro (compra e venda)

c)   Comprador; Produto; Adicionais; Venda.

d)
Comprador: Nome; Idade; Gênero; Profissão;
Produto: Tipo; Quantidade de Rodas; Ano; Modelo; Preço;
Adicionais: Seguro; Multimídia; Alarme; Total Adicional.
Venda: [Comprador]; [Produto]; [Adicionais]; Data; Hora; Valor Total;
e)
Cadastro do Comprador, Produto, Adicionais e Venda;
Cálculo do valor total da venda;
Gravação de todas as informações da venda em um arquivo gerado dinamicamente (o nome do arquivo é a data e a hora da venda);
Listagem dos produtos comprados e confirmação de venda;
Consulta de uma Venda, informando o nome do arquivo;
*/

int main(void){
  Comprador comp;
  Produto prod;
  Adicionais add;
  Venda vend;
  
  Menu(comp, prod, add, vend);
  
  /*
  printf("Nome do Cliente: ");
  fgets(comp.nome, sizeof(comp.nome), stdin);

  printf("\n\nO nome do cliente eh: %s", comp.nome);
  */
}