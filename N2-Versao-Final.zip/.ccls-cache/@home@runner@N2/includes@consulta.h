void Consulta(){
  //Declaração das variáveis
    char data[50], hora[50], nome_Arq[50] = "Dados/";

  //Declaração das variáveis de consulta
  char nome[50], tipo[50];
  float valor_Total;
  
  // Leitura dos dados
    printf("Data da Venda (dd-mm-aaaa): ");
    fgets(data, sizeof(data), stdin);
    retiraQuebra(data);
  
    printf("Hora da Venda (hh.mm): ");
    fgets(hora, sizeof(hora), stdin);
    retiraQuebra(hora);

  //Concatenações
    strcat(nome_Arq, data);
    strcat(nome_Arq, "_");
    strcat(nome_Arq, hora);
    strcat(nome_Arq, ".txt");

  //Abre o arquivo
  FILE *arq = fopen(nome_Arq, "r");

  //Retorna erro caso o arquivo não exista
  if(arq == NULL){
    printf("Erro ao abrir o arquivo.");
    return 1;
  }

  //Lê e armazena as informações do arquivo
  fscanf(arq, "%50[^;];%50[^;];%f", &nome, &tipo, &valor_Total);
  
  //Exibe as informações
  printf("\n\nO cliente %s comprou um(a) %s no valor total de: R$ %.2f", nome, tipo, valor_Total);
  clear();
}