//Cria uma nova linha (como um endl no C++)
void endl() { printf("\n"); }

//Limpa o buffer
void clear(void){ while (getchar() != '\n'); }

//Retira a quebra de linha de uma entrada de string
void retiraQuebra(char *texto) { 
	int i;
	i = strcspn(texto, "\n"); 
	// printf("A quebra de linha foi encontrada no índice %d\n", i);
	texto[i] = '\0'; 
}